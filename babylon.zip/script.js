console.log("itsAlive");
function init() {
    var canvas = document.getElementById('babylonCanvas');
    var engine = new BABYLON.Engine(canvas, true);
    var sceneB = new BABYLON.Scene(engine);
    var camera = new BABYLON.ArcRotateCamera("camera", 1, 0.8, 10, new BABYLON.Vector3(0, 0, 0), sceneB);
    var light = new BABYLON.DirectionalLight("light", new BABYLON.Vector3(-20, -20, 0), sceneB);
    light.diffuse = new BABYLON.Color3(1, 0, 0);
    light.specular = new BABYLON.Color3(1, 1, 1);
    var box = BABYLON.Mesh.CreateBox("box", 1.0, sceneB);
    var material = new BABYLON.StandardMaterial("texture", sceneB);
    box.material = material;
    sceneB.activeCamera.attachControl(canvas);
    engine.runRenderLoop(function () {
        sceneB.render();
    });
}
